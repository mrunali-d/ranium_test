.. toctree::
    :maxdepth: 2
    :caption: CakePHP DebugKit

    /index
